import {format, delay} from 'roadhog-api-doc';


const noProxy = process.env.NO_PROXY === 'true';

console.log('是否开启代理',noProxy);

const proxy = {

};

export default delay(proxy,0);
