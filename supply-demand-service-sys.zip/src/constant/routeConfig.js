export const routeConfig = {
  "/":'首页',
  "/detail":'需求详情',
  "/provide":'提交方案',
  "/publish":'发布需求',
  "/me":'个人中心',
  "/req":'需求详情',
  "/solution":'方案详情',
}
